import { boolean, integer, pgTable, real, serial, text, timestamp } from "drizzle-orm/pg-core";

/**
 * Kullanıcı profilleri
 * Her kullanıcının kendi ismi, 4 haneli PIN şifresi ve kendine özel saatlik ücreti bulunur.
 * `maskName` true ise ortak giriş listesinde soyadı gizlenir (Örn: Ahmet Yılmaz -> Ahmet Y.).
 */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  pin: text("pin").notNull(), // 4 haneli PIN
  hourlyRate: integer("hourly_rate").notNull().default(250),
  maskName: boolean("mask_name").notNull().default(false), // Soyadı gizleme opsiyonu
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" })
    .notNull()
    .defaultNow(),
});

/**
 * Mesai ve İzin kayıtları
 */
export const timeEntries = pgTable("time_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  date: text("date").notNull(), // YYYY-MM-DD
  type: text("type").notNull().default("work"), // 'work' | 'paid_leave' | 'unpaid_leave'
  checkIn: timestamp("check_in", { withTimezone: true, mode: "date" }),
  checkOut: timestamp("check_out", { withTimezone: true, mode: "date" }),
  isManual: boolean("is_manual").notNull().default(false),
  manualHours: real("manual_hours"), // Örneğin elle 6.5 saat girildiğinde
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" })
    .notNull()
    .defaultNow(),
});
