"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  CircleCheck,
  House,
  Info,
  CalendarDays,
  TriangleAlert,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/time";

export type Tab = "home" | "history" | "report";

export interface UIToast {
  id: number;
  kind: "ok" | "err" | "info";
  title: string;
  sub?: string;
}

/* ------------------------------ Durum Çubuğu ve Island Kaldırıldı ----------------------------- */

export function StatusBar({ now }: { now: Date }) {
  // Telefonun kaba barını kaldırdık, boş dönüyoruz veya sadece çok sade bir boşluk bırakıyoruz.
  return <div className="h-4" />;
}

export function Island({
  working,
  elapsedMs,
}: {
  working: boolean;
  elapsedMs: number;
}) {
  // Dynamic Island'ı kaldırdık
  return null;
}

/* -------------------------------- Tab Bar -------------------------------- */

const TABS: { id: Tab; label: string; icon: LucideIcon }[] = [
  { id: "home", label: "Ana Sayfa", icon: House },
  { id: "history", label: "Geçmiş", icon: CalendarDays },
  { id: "report", label: "Ay Sonu", icon: Wallet },
];

export function TabBar({
  tab,
  onChange,
  working,
}: {
  tab: Tab;
  onChange: (t: Tab) => void;
  working: boolean;
}) {
  return (
    <nav className="absolute inset-x-5 bottom-4 z-40">
      <div className="bg-zinc-950/90 border border-zinc-900 flex items-center rounded-2xl p-1.5 shadow-[0_12px_32px_rgba(0,0,0,0.8)] backdrop-blur-md">
        {TABS.map((t) => {
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              className="relative flex-1 rounded-xl py-2.5 outline-none transition-transform active:scale-95"
            >
              {active && (
                <motion.span
                  layoutId="tab-pill"
                  transition={{ type: "spring", stiffness: 420, damping: 34 }}
                  className="absolute inset-0 rounded-xl border border-zinc-800 bg-zinc-900/60"
                />
              )}
              <span
                className={cn(
                  "relative flex flex-col items-center gap-[3px] transition-colors duration-200",
                  active ? "text-emerald-400" : "text-zinc-500",
                )}
              >
                <span className="relative">
                  <t.icon size={18} strokeWidth={active ? 2.5 : 1.9} />
                  {t.id === "home" && working && (
                    <span className="absolute -right-1.5 -top-1 size-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.9)]" />
                  )}
                </span>
                <span className="text-[10px] font-bold">{t.label}</span>
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

/* ------------------------------- Bildirimler ----------------------------- */

export function Toasts({ toasts }: { toasts: UIToast[] }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-4 z-[70] flex flex-col items-center gap-2 px-6">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            layout
            initial={{ opacity: 0, y: -18, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -14, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 440, damping: 32 }}
            className="flex items-center gap-2.5 rounded-2xl border border-zinc-800 bg-zinc-950/95 py-2 pl-3 pr-4 shadow-xl backdrop-blur-xl"
          >
            <span
              className={cn(
                "grid size-6 shrink-0 place-items-center rounded-lg",
                t.kind === "ok" && "bg-emerald-500/10 text-emerald-400",
                t.kind === "err" && "bg-rose-500/10 text-rose-400",
                t.kind === "info" && "bg-zinc-900 text-zinc-400",
              )}
            >
              {t.kind === "ok" ? (
                <CircleCheck size={14} strokeWidth={2.4} />
              ) : t.kind === "err" ? (
                <TriangleAlert size={14} strokeWidth={2.4} />
              ) : (
                <Info size={14} strokeWidth={2.4} />
              )}
            </span>
            <div>
              <div className="text-[12px] font-bold leading-tight text-zinc-100">{t.title}</div>
              {t.sub && (
                <div className="tabular-nums text-[10px] leading-tight text-zinc-500 mt-0.5">
                  {t.sub}
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
