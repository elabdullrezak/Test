"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn, fmtMoney, monthLabel, shiftMonth } from "@/lib/time";

/** Kademeli sayaç animasyonu ile para gösterimi */
export function CountUpMoney({ value, className }: { value: number; className?: string }) {
  const v = useAnimatedNumber(value);
  return <span className={cn("tabular-nums", className)}>{fmtMoney(v)}</span>;
}

function useAnimatedNumber(value: number) {
  const [display, setDisplay] = useState(value);
  const current = useRef(value);
  useEffect(() => {
    const from = current.current;
    const to = value;
    if (from === to) return;
    const start = performance.now();
    const dur = 750;
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const e = 1 - Math.pow(1 - p, 4);
      const nv = from + (to - from) * e;
      current.current = nv;
      setDisplay(nv);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return display;
}

/** iOS tarzı sade ay seçici */
export function MonthSwitcher({
  month,
  onChange,
  max,
}: {
  month: string;
  onChange: (m: string) => void;
  max?: string;
}) {
  const canNext = !max || month < max;
  return (
    <div className="flex items-center gap-1 rounded-2xl bg-zinc-900 border border-zinc-800 p-1">
      <button
        aria-label="Önceki ay"
        onClick={() => onChange(shiftMonth(month, -1))}
        className="grid size-8 place-items-center rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors active:scale-95"
      >
        <ChevronLeft size={16} strokeWidth={2.5} />
      </button>
      <span className="min-w-[100px] text-center text-[13px] font-bold tracking-tight text-zinc-200">
        {monthLabel(month)}
      </span>
      <button
        aria-label="Sonraki ay"
        disabled={!canNext}
        onClick={() => onChange(shiftMonth(month, 1))}
        className="grid size-8 place-items-center rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors active:scale-95 disabled:opacity-20"
      >
        <ChevronRight size={16} strokeWidth={2.5} />
      </button>
    </div>
  );
}

/** Büyük sade başlık ve üst etiket */
export function ViewHeader({
  kicker,
  title,
  right,
}: {
  kicker: string;
  title: string;
  right?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800/60 pb-6 mb-6">
      <div>
        <div className="text-[11px] font-bold uppercase tracking-[0.2em] text-emerald-500">
          {kicker}
        </div>
        <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-white">
          {title}
        </h2>
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  );
}

/** Sade ve Şık Modal Bileşeni */
export function Modal({
  isOpen,
  onClose,
  title,
  children,
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Arka Plan Karartısı */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />
      
      {/* Modal Kutusu */}
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-950 p-6 shadow-2xl transition-all max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between border-b border-zinc-900 pb-4 mb-5 shrink-0">
          <h3 className="text-lg font-bold text-white">{title}</h3>
          <button
            onClick={onClose}
            className="rounded-xl p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
          >
            ✕
          </button>
        </div>
        {/* Scrollable content area so bottom buttons are always visible on all mobile screens */}
        <div className="overflow-y-auto no-scrollbar pr-1 pb-2 flex-1 space-y-4">
          {children}
        </div>
      </div>
    </div>
  );
}
