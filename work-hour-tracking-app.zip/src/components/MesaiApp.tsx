"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Lock, Plus, UserPlus, Users, Loader2 } from "lucide-react";
import { api, type TimeEntry, type UserProfile } from "@/lib/api";
import { dateKey, entryMs, fmtClock, fmtMoney, monthKey } from "@/lib/time";
import { StatusBar, TabBar, Toasts, type Tab, type UIToast } from "@/components/chrome";
import HomeView from "@/components/views/HomeView";
import HistoryView from "@/components/views/HistoryView";
import ReportView from "@/components/views/ReportView";

let toastSeq = 0;

export default function MesaiApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [month, setMonth] = useState<string>(() => monthKey());
  const [entries, setEntries] = useState<TimeEntry[] | null>(null);
  const [rate, setRate] = useState<number>(250);
  const [busy, setBusy] = useState<"in" | "out" | null>(null);
  const [now, setNow] = useState<Date>(() => new Date());
  const [toasts, setToasts] = useState<UIToast[]>([]);

  // Çoklu kullanıcı durumları
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [activeUser, setActiveUser] = useState<UserProfile | null>(null);
  const [loadingProfiles, setLoadingProfiles] = useState(true);

  // Giriş / Profil Seçim / Şifre ekranı durumları
  const [selectedUserForLogin, setSelectedUserForLogin] = useState<UserProfile | null>(null);
  const [pinInput, setPinInput] = useState("");
  const [loginError, setLoginError] = useState("");

  // Yeni profil oluşturma durumları
  const [showCreateProfile, setShowCreateProfile] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");
  const [newProfilePin, setNewProfilePin] = useState("");
  const [newProfileRate, setNewProfileRate] = useState("250");
  const [newProfileMask, setNewProfileMask] = useState(false);
  const [createError, setCreateError] = useState("");

  const pushToast = useCallback(
    (kind: UIToast["kind"], title: string, sub?: string) => {
      const id = ++toastSeq;
      setToasts((ts) => [...ts.slice(-1), { id, kind, title, sub }]);
      setTimeout(
        () => setToasts((ts) => ts.filter((t) => t.id !== id)),
        2700,
      );
    },
    [],
  );

  // Profilleri yükle (Tekil Tanım)
  const loadProfiles = useCallback(async () => {
    setLoadingProfiles(true);
    try {
      const { users } = await api.listUsers();
      setProfiles(users);
      
      if (typeof window !== "undefined") {
        const savedId = localStorage.getItem("active_user_id");
        if (savedId) {
          const found = users.find((u) => u.id === Number(savedId));
          if (found) {
            const savedName = localStorage.getItem("active_user_name") || found.name;
            setActiveUser({
              ...found,
              name: savedName
            });
            setRate(found.hourlyRate);
          }
        }
      }
    } catch {
      pushToast("err", "Profiller yüklenemedi");
    } finally {
      setLoadingProfiles(false);
    }
  }, [pushToast]);

  useEffect(() => {
    loadProfiles();
  }, [loadProfiles]);

  // Kayıtları yenile (Tekil Tanım)
  const refresh = useCallback(async (m: string) => {
    if (typeof window === "undefined" || !localStorage.getItem("active_user_id")) return;
    try {
      const { entries } = await api.listEntries(m);
      setEntries(entries);
    } catch {
      setEntries([]);
      pushToast("err", "Kayıtlar yüklenemedi");
    }
  }, [pushToast]);

  /* canlı saat ve arka plandan geri dönüşte anında senkronizasyon */
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);

    const handleSync = () => {
      setNow(new Date());
      const savedId = typeof window !== "undefined" ? localStorage.getItem("active_user_id") : null;
      if (savedId) {
        refresh(month);
      }
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === "visible") {
        handleSync();
      }
    };

    window.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("focus", handleSync);

    return () => {
      clearInterval(t);
      window.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("focus", handleSync);
    };
  }, [month, refresh]);

  /* aktif kullanıcı veya ay değişince kayıtları çek */
  useEffect(() => {
    if (activeUser) {
      setEntries(null);
      refresh(month);
    }
  }, [month, activeUser, refresh]);

  /* ana sayfaya dönünce her zaman güncel aya geç */
  useEffect(() => {
    if (tab === "home") {
      const cur = monthKey();
      setMonth((m) => (m === cur ? m : cur));
    }
  }, [tab]);

  const nowMs = now.getTime();
  const today = dateKey(now);

  const todayEntries = useMemo(
    () => (entries ?? []).filter((e) => e.date === today),
    [entries, today],
  );
  
  const openEntry = useMemo(
    () => (entries ?? []).find((e) => e.type === "work" && !e.checkOut) ?? null,
    [entries],
  );
  
  const working = openEntry !== null;
  const elapsedMs = openEntry ? entryMs(openEntry, nowMs) : 0;
  
  const todayMs = useMemo(
    () => todayEntries.reduce((a, e) => a + entryMs(e, nowMs), 0),
    [todayEntries, nowMs],
  );
  
  const monthMs = useMemo(
    () =>
      (entries ?? [])
        .filter((e) => e.type !== "work" || e.checkOut)
        .reduce((a, e) => a + entryMs(e), 0),
    [entries],
  );
  
  const daysWorked = useMemo(
    () => new Set((entries ?? []).filter((e) => e.type !== "work" || e.checkOut).map((e) => e.date))
      .size,
    [entries],
  );

  const buzz = (pattern: number | number[] = 14) => {
    try {
      navigator.vibrate?.(pattern);
    } catch {
      /* yoksay */
    }
  };

  /* ------------------------------- eylemler ------------------------------ */

  const doCheckIn = async () => {
    if (busy || working || !activeUser) return;
    setBusy("in");
    buzz(16);
    try {
      const { entry } = await api.checkIn(dateKey());
      await refresh(month);
      pushToast("ok", "Giriş kaydedildi", fmtClock(entry.checkIn));
    } catch (e: any) {
      pushToast("err", e.message || "Giriş kaydedilemedi");
    } finally {
      setBusy(null);
    }
  };

  const doCheckOut = async () => {
    if (busy || !working || !activeUser) return;
    setBusy("out");
    buzz(16);
    try {
      const { entry } = await api.checkOut();
      await refresh(month);
      pushToast(
        "ok",
        "Çıkış kaydedildi",
        entry.checkOut ? fmtClock(entry.checkOut) : undefined,
      );
    } catch (e: any) {
      pushToast("err", e.message || "Çıkış kaydedilemedi");
    } finally {
      setBusy(null);
    }
  };

  const doAddPast = async (data: { date: string; checkInTime: string; checkOutTime: string; notes?: string }) => {
    buzz(10);
    await api.addPastEntry(data);
    await refresh(month);
    pushToast("ok", "Geçmiş mesai eklendi", `${data.date} | ${data.checkInTime}-${data.checkOutTime}`);
  };

  const doAddLeave = async (data: { date: string; type: "paid_leave" | "unpaid_leave"; notes?: string }) => {
    buzz(10);
    await api.addLeaveEntry(data);
    await refresh(month);
    pushToast("ok", data.type === "paid_leave" ? "Ücretli İzin Eklendi" : "Ücretsiz İzin Eklendi", data.date);
  };

  const doDelete = async (id: number) => {
    buzz(8);
    try {
      await api.removeEntry(id);
      setEntries((es) => (es ? es.filter((e) => e.id !== id) : es));
      pushToast("info", "Kayıt silindi");
    } catch {
      pushToast("err", "Kayıt silinemedi");
    }
  };

  const doSaveRate = async (r: number) => {
    try {
      const { hourlyRate } = await api.saveRate(r);
      setRate(hourlyRate);
      if (activeUser) {
        setActiveUser({ ...activeUser, hourlyRate });
      }
      pushToast("ok", "Saatlik ücret güncellendi", `${fmtMoney(hourlyRate)} / saat`);
    } catch {
      pushToast("err", "Ücret kaydedilemedi");
    }
  };

  // Kendi profilini güncelleme (Yeni)
  const doUpdateProfile = async (data: { name?: string; pin?: string; hourlyRate?: number; maskName?: boolean }) => {
    try {
      const res = await api.updateProfile(data);
      setActiveUser(res.user);
      setRate(res.user.hourlyRate);
      
      // Lokal hafızayı da güncelle
      if (typeof window !== "undefined") {
        localStorage.setItem("active_user_name", res.user.name);
      }
      
      await loadProfiles();
      pushToast("ok", "Bilgileriniz başarıyla güncellendi");
    } catch (err: any) {
      throw new Error(err.message || "Güncelleme başarısız");
    }
  };

  // Kendi profilini silme (Yeni)
  const doDeleteProfile = async () => {
    try {
      await api.deleteProfile();
      
      // Oturumu tamamen kapat
      localStorage.removeItem("active_user_id");
      localStorage.removeItem("active_user_name");
      setActiveUser(null);
      setEntries(null);
      setTab("home");
      
      await loadProfiles();
      pushToast("info", "Profiliniz ve tüm kayıtlarınız başarıyla silindi");
    } catch (err: any) {
      throw new Error(err.message || "Profil silinemedi");
    }
  };

  const handleProfileLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    if (!selectedUserForLogin || pinInput.length !== 4) return;

    try {
      const res = await api.login(selectedUserForLogin.id, pinInput);
      if (res.success) {
        localStorage.setItem("active_user_id", String(res.user.id));
        localStorage.setItem("active_user_name", res.user.name); // Full adını local'e yazalım
        setActiveUser(res.user);
        setRate(res.user.hourlyRate);
        setPinInput("");
        setSelectedUserForLogin(null);
        pushToast("ok", `Hoş geldiniz, ${res.user.name}`);
      }
    } catch (err: any) {
      setLoginError(err.message || "Hatalı PIN şifresi girdiniz");
      setPinInput("");
    }
  };

  const handleCreateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError("");
    const parsedRate = Number(newProfileRate);
    if (!newProfileName.trim() || !/^\d{4}$/.test(newProfilePin) || isNaN(parsedRate)) {
      setCreateError("Lütfen bilgileri tam ve doğru girin.");
      return;
    }

    try {
      await api.createUser(newProfileName, newProfilePin, parsedRate, newProfileMask);
      pushToast("ok", "Yeni profil başarıyla oluşturuldu");
      setNewProfileName("");
      setNewProfilePin("");
      setNewProfileRate("250");
      setNewProfileMask(false);
      setShowCreateProfile(false);
      await loadProfiles();
    } catch (err: any) {
      setCreateError(err.message || "Profil oluşturulurken hata oluştu");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("active_user_id");
    localStorage.removeItem("active_user_name");
    setActiveUser(null);
    setEntries(null);
    setTab("home");
    pushToast("info", "Oturum kapatıldı");
  };

  /* ---------------------- GİRİŞ EKRANI / PROFİL SEÇİCİ -------------------- */

  if (!activeUser) {
    return (
      <div className="min-h-full flex flex-col justify-center px-6 py-12">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        
        {loadingProfiles ? (
          <div className="flex flex-col items-center justify-center gap-3 py-12">
            <Loader2 className="animate-spin text-emerald-500" size={32} />
            <div className="text-sm font-semibold text-zinc-500">Profiller yükleniyor...</div>
          </div>
        ) : showCreateProfile ? (
          /* YENİ PROFİL OLUŞTURMA FORMU */
          <div className="w-full max-w-sm mx-auto bg-zinc-950 border border-zinc-900 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
            <h3 className="text-xl font-extrabold text-white mb-1">Profil Oluştur</h3>
            <p className="text-xs text-zinc-500 mb-5">Herkes için ayrı profil ve PIN şifresi.</p>

            {createError && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs p-3 rounded-xl mb-4">
                {createError}
              </div>
            )}

            <form onSubmit={handleCreateProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">Adınız / Rumuz</label>
                <input
                  type="text"
                  required
                  placeholder="Örn: Ahmet Yılmaz"
                  value={newProfileName}
                  onChange={(e) => setNewProfileName(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">4 Haneli Giriş PIN Şifresi</label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  required
                  placeholder="Örn: 1234"
                  value={newProfilePin}
                  onChange={(e) => setNewProfilePin(e.target.value.replace(/\D/g, ""))}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white tracking-widest text-center rounded-xl p-2.5 text-base font-extrabold outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 mb-1">Varsayılan Saatlik Ücret (₺)</label>
                <input
                  type="number"
                  required
                  placeholder="250"
                  value={newProfileRate}
                  onChange={(e) => setNewProfileRate(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
                />
              </div>

              {/* GİZLİLİK SEÇENEĞİ (Yeni Profilde de Seçilebilir) */}
              <div className="flex items-center justify-between gap-3 bg-zinc-900 border border-zinc-850 p-3 rounded-xl">
                <div className="text-xs font-bold text-zinc-300">Soyadımı Gizle (Ahmet Y. vb.)</div>
                <input
                  type="checkbox"
                  checked={newProfileMask}
                  onChange={(e) => setNewProfileMask(e.target.checked)}
                  className="size-4 accent-emerald-500 cursor-pointer"
                />
              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateProfile(false)}
                  className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-xl py-3 text-xs transition-all"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl py-3 text-xs transition-all shadow-lg shadow-emerald-500/10"
                >
                  Oluştur
                </button>
              </div>
            </form>
          </div>
        ) : selectedUserForLogin ? (
          /* PIN KİLİT EKRANI */
          <div className="w-full max-w-sm mx-auto bg-zinc-950 border border-zinc-900 rounded-3xl p-6 shadow-2xl text-center">
            <div className="mx-auto w-12 h-12 grid place-items-center rounded-2xl bg-emerald-500/10 text-emerald-400 mb-4">
              <Lock size={20} />
            </div>
            
            <h3 className="text-lg font-bold text-white">{selectedUserForLogin.name}</h3>
            <p className="text-xs text-zinc-500 mt-1 mb-5">Devam etmek için 4 haneli PIN şifrenizi girin.</p>

            {loginError && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs p-3 rounded-xl mb-4">
                {loginError}
              </div>
            )}

            <form onSubmit={handleProfileLogin} className="space-y-4">
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                autoFocus
                required
                placeholder="PIN"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ""))}
                className="w-full bg-zinc-900 border border-zinc-800 text-white tracking-[0.6em] text-center rounded-2xl p-3.5 text-2xl font-black outline-none focus:border-emerald-500"
              />

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedUserForLogin(null);
                    setPinInput("");
                    setLoginError("");
                  }}
                  className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-xl py-2.5 text-xs transition-all"
                >
                  Geri Dön
                </button>
                <button
                  type="submit"
                  disabled={pinInput.length !== 4}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl py-2.5 text-xs disabled:opacity-30 transition-all"
                >
                  Onayla
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* PROFİL SEÇİM LİSTESİ */
          <div className="w-full max-w-sm mx-auto">
            <div className="text-center mb-6">
              <span className="inline-flex items-center gap-2 rounded-full bg-zinc-900 border border-zinc-800 px-3 py-1.5 text-[10px] font-bold tracking-widest text-zinc-400 mb-3">
                <Users size={12} className="text-emerald-400" />
                PROFİL SEÇİMİ
              </span>
              <h2 className="text-2xl font-extrabold text-white tracking-tight">Kullanıcı Girişi</h2>
              <p className="text-xs text-zinc-500 mt-1">İşlemlere başlamak için bir profil seçin veya yeni bir tane oluşturun.</p>
            </div>

            <div className="space-y-2.5 mb-6 max-h-[320px] overflow-y-auto no-scrollbar">
              {profiles.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedUserForLogin(p)}
                  className="w-full bg-zinc-950 hover:bg-zinc-900 border border-zinc-900 hover:border-zinc-800 p-4 rounded-2xl text-left flex items-center justify-between transition-all active:scale-[0.98]"
                >
                  <div>
                    <div className="text-sm font-bold text-zinc-100">{p.name}</div>
                    <div className="text-[10px] text-zinc-500 mt-0.5">Saatlik Ücret: {fmtMoney(p.hourlyRate)}</div>
                  </div>
                  <Lock size={14} className="text-zinc-600" />
                </button>
              ))}

              {profiles.length === 0 && (
                <div className="text-center py-8 text-xs text-zinc-600 font-medium">
                  Henüz kayıtlı bir profil yok. Aşağıdaki butona dokunarak ilk profili oluşturabilirsiniz!
                </div>
              )}
            </div>

            <button
              onClick={() => setShowCreateProfile(true)}
              className="w-full flex items-center justify-center gap-2 rounded-2xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-xs font-bold text-emerald-400 p-3.5 transition-all active:scale-[0.98]"
            >
              <UserPlus size={15} />
              Yeni Profil Oluştur
            </button>
          </div>
        )}

        <Toasts toasts={toasts} />
      </div>
    );
  }

  /* ------------------- ANA UYGULAMA (OTURUM AÇIKKEN) --------------------- */

  return (
    <div className="relative z-10 flex h-full flex-col">
      <StatusBar now={now} />

      <main className="no-scrollbar relative flex-1 overflow-y-auto overscroll-contain px-5 pb-[114px] pt-4 max-w-lg w-full mx-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: [0.32, 0.72, 0, 1] }}
          >
            {tab === "home" && (
              <HomeView
                now={now}
                working={working}
                openEntry={openEntry}
                todayEntries={todayEntries}
                elapsedMs={elapsedMs}
                todayMs={todayMs}
                busy={busy}
                loading={entries === null}
                onCheckIn={doCheckIn}
                onCheckOut={doCheckOut}
                activeUser={activeUser}
                onLogout={handleLogout}
                onAddPast={doAddPast}
                onAddLeave={doAddLeave}
                onUpdateProfile={doUpdateProfile}
                onDeleteProfile={doDeleteProfile}
              />
            )}
            {tab === "history" && (
              <HistoryView
                month={month}
                onMonth={setMonth}
                entries={entries}
                nowMs={nowMs}
                onDelete={doDelete}
              />
            )}
            {tab === "report" && (
              <ReportView
                month={month}
                onMonth={setMonth}
                entries={entries ?? []}
                monthMs={monthMs}
                daysWorked={daysWorked}
                rate={rate}
                onSaveRate={doSaveRate}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      <TabBar tab={tab} onChange={setTab} working={working} />
      <Toasts toasts={toasts} />
    </div>
  );
}
