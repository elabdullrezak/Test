"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { BadgeInfo, Check, Download, Landmark } from "lucide-react";
import type { TimeEntry } from "@/lib/api";
import { CountUpMoney, MonthSwitcher, ViewHeader } from "@/components/ui";
import {
  cn,
  durParts,
  entryMs,
  fmtClock,
  fmtDur,
  fmtMoney,
  fmtNum,
  monthKey,
  monthLabel,
} from "@/lib/time";

interface Props {
  month: string;
  onMonth: (m: string) => void;
  entries: TimeEntry[];
  monthMs: number;
  daysWorked: number;
  rate: number;
  onSaveRate: (r: number) => void;
}

const QUICK_RATES = [150, 250, 350, 500];

export default function ReportView(p: Props) {
  const hours = durParts(p.monthMs).hours;
  const gross = hours * p.rate;
  const avgMs = p.daysWorked > 0 ? p.monthMs / p.daysWorked : 0;
  const hasOpen = p.entries.some((e) => e.type === "work" && !e.checkOut);

  const [val, setVal] = useState(String(p.rate));
  useEffect(() => setVal(String(p.rate)), [p.rate]);
  const parsed = Number(val.replace(",", "."));
  const dirty =
    val.trim() !== "" && Number.isFinite(parsed) && parsed !== p.rate;

  const save = () => {
    if (dirty && parsed >= 0) p.onSaveRate(Math.round(parsed * 100) / 100);
  };

  // İzin sayıları
  const paidLeaves = p.entries.filter((e) => e.type === "paid_leave").length;
  const unpaidLeaves = p.entries.filter((e) => e.type === "unpaid_leave").length;

  // CSV DIŞA AKTARMA (Kullanıcı Talebi Ekstra Özellik)
  const exportToCSV = () => {
    try {
      const headers = ["Tarih", "Tür", "Giriş Saati", "Çıkış Saati", "Çalışılan Süre (Saat)", "Notlar"];
      const rows = p.entries.map((e) => {
        const isLeave = e.type === "paid_leave" || e.type === "unpaid_leave";
        const durHours = e.type === "unpaid_leave" ? 0 : (entryMs(e) / 3600000);
        let typeStr = "Normal Mesai";
        if (e.type === "paid_leave") typeStr = "Ücretli İzin";
        if (e.type === "unpaid_leave") typeStr = "Ücretsiz İzin";

        return [
          e.date,
          typeStr,
          e.checkIn ? fmtClock(e.checkIn, false) : "—",
          e.checkOut ? fmtClock(e.checkOut, false) : "—",
          durHours.toFixed(2),
          e.notes || "",
        ];
      });

      // CSV oluşturma (Türkçe karakterlerin Excel'de düzgün açılması için BOM eklenmiştir)
      const csvContent = "\uFEFF" + [headers.join(";"), ...rows.map((r) => r.join(";"))].join("\n");
      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `Mesai_Raporu_${p.month}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("CSV Dışa aktarma hatası:", err);
    }
  };

  return (
    <div>
      <ViewHeader
        kicker="Kazanç Tablosu"
        title="Ay Sonu"
        right={
          <MonthSwitcher month={p.month} onChange={p.onMonth} max={monthKey()} />
        }
      />

      {/* Büyük Kazanç Kartı */}
      <div className="relative overflow-hidden rounded-3xl border border-zinc-800 bg-zinc-950 p-6 shadow-xl mb-6">
        <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-emerald-500/5 blur-3xl pointer-events-none" />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-emerald-500">
            <Landmark size={14} />
            Ay Sonu Hak Ediş
          </div>
          
          {/* CSV İndirme Butonu */}
          {p.entries.length > 0 && (
            <button
              onClick={exportToCSV}
              className="flex items-center gap-1.5 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 hover:text-white text-zinc-300 text-[10px] font-bold px-3 py-1.5 rounded-xl transition-all"
            >
              <Download size={12} />
              CSV İndir
            </button>
          )}
        </div>
        
        <div className="mt-3 text-4xl font-black text-white leading-none">
          <CountUpMoney value={gross} />
        </div>
        
        <div className="mt-2 text-xs text-zinc-500 font-semibold tabular-nums">
          {fmtNum(hours)} Saat Toplam Mesai × {fmtMoney(p.rate)} / Saat
        </div>

        {/* Detay Grid */}
        <div className="mt-6 pt-5 border-t border-zinc-900 grid grid-cols-3 gap-2 text-center">
          {[
            { label: "Toplam Mesai", value: fmtDur(p.monthMs) },
            { label: "İş Günü", value: `${p.daysWorked} Gün` },
            { label: "Günlük Ort.", value: p.daysWorked ? fmtDur(avgMs) : "—" },
          ].map((s) => (
            <div key={s.label}>
              <div className="text-sm font-extrabold text-zinc-100 tabular-nums">{s.value}</div>
              <div className="mt-1 text-[9px] font-bold uppercase tracking-wider text-zinc-500">
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* İzinler Detay Kartı */}
      {(paidLeaves > 0 || unpaidLeaves > 0) && (
        <div className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 mb-6 grid grid-cols-2 gap-4">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Ücretli İzin</div>
            <div className="text-base font-extrabold text-emerald-400 mt-1">{paidLeaves} Gün</div>
            <div className="text-[10px] text-zinc-600 mt-0.5">8&apos;er saat mesai sayıldı</div>
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Ücretsiz İzin</div>
            <div className="text-base font-extrabold text-amber-500 mt-1">{unpaidLeaves} Gün</div>
            <div className="text-[10px] text-zinc-600 mt-0.5">Ödeme yansıtılmadı</div>
          </div>
        </div>
      )}

      {hasOpen && (
        <div className="bg-zinc-900/40 border border-zinc-800/80 rounded-2xl p-3.5 text-xs text-zinc-400 mb-6 flex items-start gap-2.5">
          <BadgeInfo size={15} className="text-emerald-500 shrink-0 mt-0.5" />
          Aktif devam eden mesainiz var. O mesai kapatılmadan bu listedeki hesaplamaya dahil edilmez.
        </div>
      )}

      {/* Saatlik Ücret Ayarı */}
      <div className="bg-zinc-950 border border-zinc-900 rounded-3xl p-5 shadow-lg">
        <div className="text-xs font-bold uppercase tracking-wider text-zinc-400">Saatlik Ücretini Güncelle</div>
        
        <div className="mt-3 flex items-center gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-2xl bg-zinc-900 text-lg font-bold text-zinc-300">
            ₺
          </span>
          <input
            value={val}
            onChange={(e) => setVal(e.target.value.replace(/[^\d.,]/g, ""))}
            onKeyDown={(e) => e.key === "Enter" && save()}
            onBlur={save}
            inputMode="decimal"
            aria-label="Saatlik ücret"
            className="w-full bg-transparent text-2xl font-black text-white outline-none placeholder:text-zinc-850"
            placeholder="0"
          />
          {dirty && (
            <motion.button
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={save}
              className="flex shrink-0 items-center gap-1 bg-emerald-500 text-black text-xs font-bold px-3 py-2 rounded-xl hover:bg-emerald-400 transition-all active:scale-95"
            >
              <Check size={13} strokeWidth={3} />
              Kaydet
            </motion.button>
          )}
        </div>

        {/* Hızlı Seçim Ücretleri */}
        <div className="mt-4 flex flex-wrap gap-2">
          {QUICK_RATES.map((r) => (
            <button
              key={r}
              onClick={() => p.onSaveRate(r)}
              className={cn(
                "rounded-xl border px-3.5 py-2 text-xs font-bold transition-all tabular-nums",
                p.rate === r
                  ? "border-emerald-500 bg-emerald-500/10 text-emerald-400"
                  : "border-zinc-800 hover:border-zinc-700 bg-zinc-900/50 text-zinc-400"
              )}
            >
              {fmtMoney(r)}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
