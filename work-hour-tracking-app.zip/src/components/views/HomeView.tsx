"use client";

import { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarDays,
  CalendarPlus,
  Clock,
  Coffee,
  LogIn,
  LogOut,
  Maximize2,
  Minimize2,
  Plus,
  User,
  X,
  ChevronLeft,
  ChevronRight,
  Briefcase,
  Settings,
  Shield,
  Trash2,
  Check,
  ChevronDown,
} from "lucide-react";
import type { TimeEntry, UserProfile } from "@/lib/api";
import { Modal } from "@/components/ui";
import {
  TR_DAYS,
  TR_MONTHS,
  TR_MONTHS_S,
  cn,
  entryMs,
  fmtClock,
  fmtDur,
  fmtHMS,
  pad,
} from "@/lib/time";

interface Props {
  now: Date;
  working: boolean;
  openEntry: TimeEntry | null;
  todayEntries: TimeEntry[];
  elapsedMs: number;
  todayMs: number;
  busy: "in" | "out" | null;
  loading: boolean;
  onCheckIn: () => void;
  onCheckOut: () => void;
  activeUser: UserProfile;
  onLogout: () => void;
  onAddPast: (data: { date: string; checkInTime: string; checkOutTime: string; notes?: string }) => Promise<void>;
  onAddLeave: (data: { date: string; type: "paid_leave" | "unpaid_leave"; notes?: string }) => Promise<void>;
  onUpdateProfile: (data: { name?: string; pin?: string; hourlyRate?: number; maskName?: boolean }) => Promise<void>;
  onDeleteProfile: () => Promise<void>;
}

const HOURS = Array.from({ length: 24 }, (_, i) => pad(i));
const MINUTES = Array.from({ length: 12 }, (_, i) => pad(i * 5));

const SHIFT_TEMPLATES = [
  { label: "Normal (08:30 - 17:30)", in: "08:30", out: "17:30" },
  { label: "Gündüz (09:00 - 18:00)", in: "09:00", out: "18:00" },
  { label: "Vardiya 2 (16:00 - 00:00)", in: "16:00", out: "23:55" },
  { label: "Yarım Gün (09:00 - 13:00)", in: "09:00", out: "13:00" },
];

export default function HomeView(p: Props) {
  const { now } = p;
  const [showPastModal, setShowPastModal] = useState(false);
  const [showLeaveModal, setShowLeaveModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const [isFullscreen, setIsFullscreen] = useState(false);

  // Manuel mesai form durumları (Custom Pickers)
  const [pastYear, setPastYear] = useState(now.getFullYear());
  const [pastMonth, setPastMonth] = useState(now.getMonth());
  const [pastDay, setPastDay] = useState<number | null>(now.getDate());

  const [pastInHour, setPastCheckInHour] = useState("09");
  const [pastInMin, setPastCheckInMin] = useState("00");
  const [pastOutHour, setPastCheckOutHour] = useState("17");
  const [pastOutMin, setPastCheckOutMin] = useState("00");

  const [pastNotes, setPastNotes] = useState("");
  const [pastError, setPastError] = useState("");

  // İzin form durumları (Custom Pickers)
  const [leaveYear, setLeaveYear] = useState(now.getFullYear());
  const [leaveMonth, setLeaveMonth] = useState(now.getMonth());
  const [leaveDay, setLeaveDay] = useState<number | null>(now.getDate());
  const [leaveType, setLeaveType] = useState<"paid_leave" | "unpaid_leave">("paid_leave");
  const [leaveNotes, setLeaveNotes] = useState("");
  const [leaveError, setLeaveError] = useState("");

  // Profil Yönetim form durumları
  const [editName, setEditName] = useState(p.activeUser.name);
  const [editPin, setEditPin] = useState("");
  const [editRate, setEditRate] = useState(String(p.activeUser.hourlyRate));
  const [editMaskName, setEditMaskName] = useState(p.activeUser.maskName);
  const [settingsError, setSettingsError] = useState("");
  const [settingsSuccess, setSettingsSuccess] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    setEditName(p.activeUser.name);
    setEditRate(String(p.activeUser.hourlyRate));
    setEditMaskName(p.activeUser.maskName);
  }, [p.activeUser]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch((err) => {
        console.error("Tam ekran hatası:", err);
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      });
    }
  };

  const selectedPastDateStr = useMemo(() => {
    if (!pastDay) return "";
    return `${pastYear}-${pad(pastMonth + 1)}-${pad(pastDay)}`;
  }, [pastYear, pastMonth, pastDay]);

  const selectedLeaveDateStr = useMemo(() => {
    if (!leaveDay) return "";
    return `${leaveYear}-${pad(leaveMonth + 1)}-${pad(leaveDay)}`;
  }, [leaveYear, leaveMonth, leaveDay]);

  const handlePastSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPastError("");
    if (!selectedPastDateStr) return setPastError("Lütfen takvimden bir gün seçin");
    
    const checkInTime = `${pastInHour}:${pastInMin}`;
    const checkOutTime = `${pastOutHour}:${pastOutMin}`;

    try {
      await p.onAddPast({
        date: selectedPastDateStr,
        checkInTime,
        checkOutTime,
        notes: pastNotes || undefined,
      });
      setShowPastModal(false);
      setPastNotes("");
    } catch (err: any) {
      setPastError(err.message || "Mesai eklenirken hata oluştu");
    }
  };

  const handleLeaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLeaveError("");
    if (!selectedLeaveDateStr) return setLeaveError("Lütfen takvimden bir gün seçin");
    try {
      await p.onAddLeave({
        date: selectedLeaveDateStr,
        type: leaveType,
        notes: leaveNotes || undefined,
      });
      setShowLeaveModal(false);
      setLeaveNotes("");
    } catch (err: any) {
      setLeaveError(err.message || "İzin eklenirken hata oluştu");
    }
  };

  const handleSettingsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSettingsError("");
    setSettingsSuccess("");
    
    const rateNum = Number(editRate);
    if (!editName.trim() || isNaN(rateNum) || rateNum <= 0) {
      setSettingsError("Lütfen geçerli bilgileri girin");
      return;
    }

    if (editPin && !/^\d{4}$/.test(editPin)) {
      setSettingsError("PIN şifresi tam 4 hane sayı olmalıdır");
      return;
    }

    try {
      await p.onUpdateProfile({
        name: editName,
        pin: editPin || undefined,
        hourlyRate: rateNum,
        maskName: editMaskName,
      });
      setEditPin("");
      setSettingsSuccess("Profil başarıyla güncellendi!");
      setTimeout(() => {
        setSettingsSuccess("");
        setShowSettingsModal(false);
      }, 1500);
    } catch (err: any) {
      setSettingsError(err.message || "Profil güncellenemedi");
    }
  };

  const handleDeleteProfile = async () => {
    try {
      await p.onDeleteProfile();
      setShowSettingsModal(false);
      setShowDeleteConfirm(false);
    } catch (err: any) {
      setSettingsError(err.message || "Profil silinemedi");
    }
  };

  const applyTemplate = (tpl: typeof SHIFT_TEMPLATES[0]) => {
    const [inH, inM] = tpl.in.split(":");
    const [outH, outM] = tpl.out.split(":");
    setPastCheckInHour(inH);
    setPastCheckInMin(inM);
    setPastCheckOutHour(outH);
    setPastCheckOutMin(outM);
  };

  return (
    <div className="space-y-6">
      {/* Kullanıcı Profili Üst Bilgi Satırı */}
      <div className="flex items-center justify-between bg-zinc-900/40 border border-zinc-900 rounded-2xl p-3 px-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowSettingsModal(true)}
            aria-label="Profil Ayarları"
            className="grid size-9 place-items-center rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-emerald-400 transition-all hover:bg-zinc-850 active:scale-90"
          >
            <Settings size={16} />
          </button>
          <div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-500">Aktif Profil</div>
            <div className="text-xs font-bold text-zinc-200">
              {p.activeUser.name} {p.activeUser.maskName && <span className="text-[9px] text-emerald-500 bg-emerald-500/10 px-1 py-0.5 rounded ml-1">Gizli</span>}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Tam Ekran Butonu */}
          <button
            onClick={toggleFullscreen}
            aria-label="Tam Ekran Yap"
            className="grid size-8 place-items-center text-zinc-400 hover:text-white bg-zinc-900 border border-zinc-800 rounded-xl transition-all active:scale-90"
          >
            {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
          </button>
          
          <button
            onClick={p.onLogout}
            className="text-xs font-semibold text-zinc-400 hover:text-rose-400 bg-zinc-900 border border-zinc-800 px-3 py-1.5 rounded-xl transition-all active:scale-95"
          >
            Profil Değiştir
          </button>
        </div>
      </div>

      {/* Büyük Saat & Gün Bilgisi */}
      <div className="text-center py-4">
        <div className="text-xs font-bold uppercase tracking-[0.25em] text-emerald-500">
          {now.getDate()} {TR_MONTHS[now.getMonth()]} {TR_DAYS[now.getDay()]}
        </div>
        <div className="mt-1 text-[54px] font-black tracking-tight text-white leading-none">
          {fmtClock(now, false)}
          <span className="text-emerald-500/50 text-[32px] font-medium ml-1">
            :{String(now.getSeconds()).padStart(2, "0")}
          </span>
        </div>
        <div className="mt-2.5 text-xs font-semibold text-zinc-500">
          {p.working ? "Mesainiz devam ediyor." : "Şu an mesai dışındasınız."}
        </div>
      </div>

      {/* Kontrol Paneli Kartı */}
      <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 border border-zinc-900 rounded-3xl p-5 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={cn("size-2.5 rounded-full", p.working ? "bg-emerald-500 animate-pulse" : "bg-zinc-600")} />
            <span className="text-[13px] font-bold uppercase tracking-wider text-zinc-400">
              {p.working ? "Mevcut Durum: Aktif Çalışıyor" : "Çalışma Durumu: Pasif"}
            </span>
          </div>
          {p.working && (
            <span className="tabular-nums text-lg font-black text-emerald-400">
              {fmtHMS(p.elapsedMs)}
            </span>
          )}
        </div>

        <div className="mt-5 grid grid-cols-2 gap-3.5">
          <button
            disabled={p.working || p.busy !== null}
            onClick={p.onCheckIn}
            className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-emerald-500 text-black font-extrabold py-3.5 hover:bg-emerald-400 disabled:opacity-30 disabled:pointer-events-none transition-all active:scale-[0.97] shadow-lg shadow-emerald-500/10"
          >
            <LogIn size={18} strokeWidth={2.5} />
            <span className="text-[13px] tracking-wide">GİRİŞ YAP</span>
          </button>
          
          <button
            disabled={!p.working || p.busy !== null}
            onClick={p.onCheckOut}
            className="flex flex-col items-center justify-center gap-2 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-rose-500 font-extrabold py-3.5 disabled:opacity-30 disabled:pointer-events-none transition-all active:scale-[0.97]"
          >
            <LogOut size={18} strokeWidth={2.5} />
            <span className="text-[13px] tracking-wide">ÇIKIŞ YAP</span>
          </button>
        </div>

        <div className="mt-5 border-t border-zinc-800/80 pt-4 flex items-center justify-between text-xs text-zinc-400">
          <span>Bugünkü Çalışma Süresi</span>
          <span className="font-bold text-zinc-200 tabular-nums">{fmtDur(p.todayMs, true)}</span>
        </div>
      </div>

      {/* Ekstra İşlemler */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => setShowPastModal(true)}
          className="flex items-center justify-center gap-2 rounded-2xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 p-3 text-xs font-bold text-zinc-300 transition-all active:scale-95"
        >
          <CalendarPlus size={14} className="text-emerald-400" />
          Geçmiş Mesai Ekle
        </button>

        <button
          onClick={() => setShowLeaveModal(true)}
          className="flex items-center justify-center gap-2 rounded-2xl bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 p-3 text-xs font-bold text-zinc-300 transition-all active:scale-95"
        >
          <Coffee size={14} className="text-amber-400" />
          İzin Günü Ekle
        </button>
      </div>

      {/* Günün Kayıtları */}
      <div className="space-y-3">
        <div className="text-[11px] font-bold uppercase tracking-widest text-zinc-500 px-1">
          Bugünkü Kayıtlar
        </div>
        <div className="bg-zinc-950 border border-zinc-900 rounded-3xl overflow-hidden divide-y divide-zinc-900">
          {p.loading ? (
            <div className="p-5 text-center text-xs text-zinc-500 animate-pulse">Yükleniyor...</div>
          ) : p.todayEntries.length === 0 ? (
            <div className="p-6 text-center text-xs text-zinc-600 font-medium">
              Bugün henüz bir mesai veya izin kaydı yok.
            </div>
          ) : (
            p.todayEntries.map((e) => {
              const open = !e.checkOut && e.type === "work";
              const isLeave = e.type === "paid_leave" || e.type === "unpaid_leave";
              const ms = entryMs(e, p.now.getTime());
              
              return (
                <div key={e.id} className="p-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        "grid size-9 place-items-center rounded-xl",
                        e.type === "paid_leave" && "bg-emerald-500/10 text-emerald-400",
                        e.type === "unpaid_leave" && "bg-amber-500/10 text-amber-400",
                        open && "bg-emerald-500/10 text-emerald-400",
                        !open && !isLeave && "bg-zinc-900 text-zinc-400",
                      )}
                    >
                      {isLeave ? <Coffee size={15} /> : <Clock size={15} />}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-zinc-100">
                        {isLeave ? (
                          <span>{e.type === "paid_leave" ? "Ücretli İzin" : "Ücretsiz İzin"}</span>
                        ) : (
                          <span>
                            {fmtClock(e.checkIn, false)} → {e.checkOut ? fmtClock(e.checkOut, false) : "Aktif"}
                          </span>
                        )}
                      </div>
                      {e.notes && <div className="text-[10px] text-zinc-500 mt-0.5">{e.notes}</div>}
                    </div>
                  </div>
                  
                  <span
                    className={cn(
                      "text-xs font-bold px-2.5 py-1 rounded-full tabular-nums",
                      e.type === "paid_leave" && "bg-emerald-500/10 text-emerald-400",
                      e.type === "unpaid_leave" && "bg-amber-500/10 text-amber-400",
                      open && "bg-emerald-500/10 text-emerald-400",
                      !open && !isLeave && "bg-zinc-900 text-zinc-400",
                    )}
                  >
                    {e.type === "unpaid_leave" ? "0sa" : fmtDur(ms)}
                  </span>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* MODAL: Profil Ayarları / Yönetimi */}
      <Modal isOpen={showSettingsModal} onClose={() => { setShowSettingsModal(false); setShowDeleteConfirm(false); }} title="Profil Ayarları">
        {!showDeleteConfirm ? (
          <form onSubmit={handleSettingsSubmit} className="space-y-4">
            {settingsError && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs p-3 rounded-xl">
                {settingsError}
              </div>
            )}
            {settingsSuccess && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs p-3 rounded-xl flex items-center gap-1.5 font-bold">
                <Check size={14} strokeWidth={3} />
                {settingsSuccess}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1">Adınız / Rumuz</label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1">4 Haneli PIN Şifresi (Sadece değiştirmek için yazın)</label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={4}
                placeholder="Değişiklik yoksa boş bırakın"
                value={editPin}
                onChange={(e) => setEditPin(e.target.value.replace(/\D/g, ""))}
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm tracking-widest text-center font-bold outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1">Varsayılan Saatlik Ücret (₺)</label>
              <input
                type="number"
                required
                value={editRate}
                onChange={(e) => setEditRate(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
              />
            </div>

            <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-3 flex items-center justify-between gap-4">
              <div className="flex items-start gap-2.5">
                <Shield size={16} className="text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-zinc-200">Soyadımı Gizle</div>
                  <div className="text-[10px] text-zinc-500 mt-0.5">Aktif edildiğinde, ortak listelerde isminizin soyadı maskelenir (Ahmet Y. şeklinde).</div>
                </div>
              </div>
              <input
                type="checkbox"
                checked={editMaskName}
                onChange={(e) => setEditMaskName(e.target.checked)}
                className="size-4 shrink-0 accent-emerald-500 cursor-pointer"
              />
            </div>

            <div className="flex flex-col gap-2 pt-3 border-t border-zinc-900 shrink-0">
              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-xl py-3 text-sm transition-all"
              >
                Bilgileri Güncelle
              </button>

              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full flex items-center justify-center gap-1.5 bg-zinc-900 hover:bg-rose-500/10 border border-zinc-800 hover:border-rose-500/20 text-rose-400 font-bold rounded-xl py-2.5 text-xs transition-all mt-1"
              >
                <Trash2 size={13} />
                Profilimi Kalıcı Olarak Sil
              </button>
            </div>
          </form>
        ) : (
          /* PROFİL SİLME ONAY ADIMI */
          <div className="space-y-4 text-center">
            <div className="mx-auto w-12 h-12 grid place-items-center rounded-2xl bg-rose-500/10 text-rose-400 mb-2">
              <Trash2 size={20} />
            </div>
            
            <h4 className="text-base font-bold text-white">Profilini Silmek İstediğine Emin misin?</h4>
            <p className="text-xs text-zinc-400 leading-relaxed px-2">
              Bu işlem geri alınamaz! <b>{p.activeUser.name}</b> profiliniz ve sisteme kayıtlı olan tüm mesaileriniz, izin günleriniz kalıcı olarak veritabanından silinecektir.
            </p>

            <div className="flex gap-2.5 pt-4 border-t border-zinc-900 shrink-0">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 font-bold rounded-xl py-2.5 text-xs transition-all"
              >
                Vazgeç
              </button>
              <button
                type="button"
                onClick={handleDeleteProfile}
                className="flex-1 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl py-2.5 text-xs transition-all shadow-lg shadow-rose-500/10"
              >
                Evet, Kalıcı Olarak Sil
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* MODAL: Manuel Geçmiş Mesai */}
      <Modal isOpen={showPastModal} onClose={() => setShowPastModal(false)} title="Geçmiş Mesai Ekle">
        <form onSubmit={handlePastSubmit} className="space-y-5">
          {pastError && <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs p-3 rounded-xl">{pastError}</div>}
          
          {/* Custom Web-Native Takvim Seçici */}
          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1.5">Tarih Seçimi</label>
            <CustomCalendar
              year={pastYear}
              month={pastMonth}
              selectedDay={pastDay}
              onSelectDay={setPastDay}
              onPrevMonth={() => {
                if (pastMonth === 0) {
                  setPastMonth(11);
                  setPastYear(pastYear - 1);
                } else {
                  setPastMonth(pastMonth - 1);
                }
              }}
              onNextMonth={() => {
                if (pastMonth === 11) {
                  setPastMonth(0);
                  setPastYear(pastYear + 1);
                } else {
                  setPastMonth(pastMonth + 1);
                }
              }}
            />
            {selectedPastDateStr && (
              <div className="text-[11px] font-bold text-emerald-400 mt-2 text-right">
                Seçilen Gün: {selectedPastDateStr}
              </div>
            )}
          </div>

          {/* Hazır Şablonlar */}
          <div>
            <label className="block text-xs font-bold text-zinc-500 mb-1.5">Hazır Saat Şablonları</label>
            <div className="flex flex-wrap gap-2">
              {SHIFT_TEMPLATES.map((t) => (
                <button
                  key={tplKey(t)}
                  type="button"
                  onClick={() => applyTemplate(t)}
                  className="bg-zinc-900 hover:bg-zinc-800 border border-zinc-800/80 text-[10px] font-bold text-zinc-300 px-2.5 py-1.5 rounded-lg transition-colors"
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom Web Saat / Dakika Seçici (Klavyeyi ve Yerel Telefon Penceresini Kesin Olarak Engeller) */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5">Giriş Saati</label>
              <CustomInlineTimeSelect
                hour={pastInHour}
                minute={pastInMin}
                onSelectHour={setPastCheckInHour}
                onSelectMin={setPastCheckInMin}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-zinc-400 mb-1.5">Çıkış Saati</label>
              <CustomInlineTimeSelect
                hour={pastOutHour}
                minute={pastOutMin}
                onSelectHour={setPastCheckOutHour}
                onSelectMin={setPastCheckOutMin}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1">Açıklama</label>
            <input
              type="text"
              placeholder="Örn: Hafta sonu fazla mesaisi"
              value={pastNotes}
              onChange={(e) => setPastNotes(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 text-black font-bold rounded-xl py-3 text-sm hover:bg-emerald-400 transition-all active:scale-[0.98] shrink-0"
          >
            Kaydet
          </button>
        </form>
      </Modal>

      {/* MODAL: İzin Günü Ekle */}
      <Modal isOpen={showLeaveModal} onClose={() => setShowLeaveModal(false)} title="İzin Günü Ekle">
        <form onSubmit={handleLeaveSubmit} className="space-y-5">
          {leaveError && <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs p-3 rounded-xl">{leaveError}</div>}

          {/* Custom Web-Native Takvim Seçici */}
          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1.5">İzin Tarihi</label>
            <CustomCalendar
              year={leaveYear}
              month={leaveMonth}
              selectedDay={leaveDay}
              onSelectDay={setLeaveDay}
              onPrevMonth={() => {
                if (leaveMonth === 0) {
                  setLeaveMonth(11);
                  setLeaveYear(leaveYear - 1);
                } else {
                  setLeaveMonth(leaveMonth - 1);
                }
              }}
              onNextMonth={() => {
                if (leaveMonth === 11) {
                  setLeaveMonth(0);
                  setLeaveYear(leaveYear + 1);
                } else {
                  setLeaveMonth(leaveMonth + 1);
                }
              }}
            />
            {selectedLeaveDateStr && (
              <div className="text-[11px] font-bold text-amber-400 mt-2 text-right">
                Seçilen Gün: {selectedLeaveDateStr}
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1.5">İzin Türü</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLeaveType("paid_leave")}
                className={cn(
                  "border rounded-xl p-3 text-xs font-bold transition-all",
                  leaveType === "paid_leave"
                    ? "bg-emerald-500/10 border-emerald-500 text-emerald-400"
                    : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white"
                )}
              >
                Ücretli İzin (8 Saat)
              </button>
              <button
                type="button"
                onClick={() => setLeaveType("unpaid_leave")}
                className={cn(
                  "border rounded-xl p-3 text-xs font-bold transition-all",
                  leaveType === "unpaid_leave"
                    ? "bg-amber-500/10 border-amber-500 text-amber-400"
                    : "bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white"
                )}
              >
                Ücretsiz İzin
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-400 mb-1">Açıklama</label>
            <input
              type="text"
              placeholder="Örn: Yıllık İzin, Rapor vb."
              value={leaveNotes}
              onChange={(e) => setLeaveNotes(e.target.value)}
              className="w-full bg-zinc-900 border border-zinc-800 text-white rounded-xl p-2.5 text-sm outline-none focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-emerald-500 text-black font-bold rounded-xl py-3 text-sm hover:bg-emerald-400 transition-all active:scale-[0.98] shrink-0"
          >
            İzin Girişini Tamamla
          </button>
        </form>
      </Modal>
    </div>
  );
}

// Key Generator for Templates
function tplKey(t: typeof SHIFT_TEMPLATES[0]) {
  return `${t.label}-${t.in}-${t.out}`;
}

/* -------------------------------------------------------------------------- */
/*       BİLEŞEN: CustomInlineTimeSelect (Native Olmayan Şık Saat Seçici)       */
/* -------------------------------------------------------------------------- */

function CustomInlineTimeSelect({
  hour,
  minute,
  onSelectHour,
  onSelectMin,
}: {
  hour: string;
  minute: string;
  onSelectHour: (h: string) => void;
  onSelectMin: (m: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Dışarı tıklanınca kapatma
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-white rounded-xl p-3 text-sm font-extrabold transition-all"
      >
        <span className="tabular-nums">{hour}:{minute}</span>
        <ChevronDown size={14} className="text-zinc-500" />
      </button>

      {isOpen && (
        <div className="absolute left-0 right-0 z-[100] mt-1.5 bg-zinc-950 border border-zinc-800 rounded-2xl p-3 shadow-2xl grid grid-cols-2 gap-3 h-52">
          {/* SAAT LİSTESİ */}
          <div className="flex flex-col overflow-y-auto no-scrollbar border-r border-zinc-900 pr-1.5 space-y-1">
            <div className="text-[9px] font-bold text-zinc-500 uppercase sticky top-0 bg-zinc-950 pb-1 text-center">Saat</div>
            {HOURS.map((h) => {
              const selected = h === hour;
              return (
                <button
                  key={`inline-h-${h}`}
                  type="button"
                  onClick={() => onSelectHour(h)}
                  className={cn(
                    "w-full py-1 text-xs font-semibold rounded-lg text-center transition-colors",
                    selected ? "bg-emerald-500 text-black font-extrabold" : "text-zinc-400 hover:bg-zinc-900"
                  )}
                >
                  {h}
                </button>
              );
            })}
          </div>

          {/* DAKİKA LİSTESİ */}
          <div className="flex flex-col overflow-y-auto no-scrollbar space-y-1">
            <div className="text-[9px] font-bold text-zinc-500 uppercase sticky top-0 bg-zinc-950 pb-1 text-center">Dakika</div>
            {MINUTES.map((m) => {
              const selected = m === minute;
              return (
                <button
                  key={`inline-m-${m}`}
                  type="button"
                  onClick={() => {
                    onSelectMin(m);
                    // Dakikayı seçince otomatik kapansın, kullanım kolaylığı
                    setIsOpen(false);
                  }}
                  className={cn(
                    "w-full py-1 text-xs font-semibold rounded-lg text-center transition-colors",
                    selected ? "bg-emerald-500 text-black font-extrabold" : "text-zinc-400 hover:bg-zinc-900"
                  )}
                >
                  {m}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*             BİLEŞEN: CustomCalendar (Web-Native Inline Takvim)            */
/* -------------------------------------------------------------------------- */

interface CalendarProps {
  year: number;
  month: number;
  selectedDay: number | null;
  onSelectDay: (day: number) => void;
  onPrevMonth: () => void;
  onNextMonth: () => void;
}

function CustomCalendar({
  year,
  month,
  selectedDay,
  onSelectDay,
  onPrevMonth,
  onNextMonth,
}: CalendarProps) {
  const daysInMonth = useMemo(() => new Date(year, month + 1, 0).getDate(), [year, month]);
  
  const startDayIndex = useMemo(() => {
    let day = new Date(year, month, 1).getDay();
    return day === 0 ? 6 : day - 1;
  }, [year, month]);

  const daysArray = useMemo(() => {
    const arr = [];
    for (let i = 0; i < startDayIndex; i++) {
      arr.push(null);
    }
    for (let i = 1; i <= daysInMonth; i++) {
      arr.push(i);
    }
    return arr;
  }, [daysInMonth, startDayIndex]);

  const daysOfWeek = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

  return (
    <div className="bg-zinc-900 border border-zinc-800/80 rounded-2xl p-3.5">
      <div className="flex items-center justify-between mb-3.5">
        <button
          type="button"
          onClick={onPrevMonth}
          className="p-1.5 text-zinc-400 hover:text-white bg-zinc-850 rounded-lg transition-colors"
        >
          <ChevronLeft size={15} />
        </button>
        <span className="text-xs font-bold text-zinc-200">
          {TR_MONTHS[month]} {year}
        </span>
        <button
          type="button"
          onClick={onNextMonth}
          className="p-1.5 text-zinc-400 hover:text-white bg-zinc-850 rounded-lg transition-colors"
        >
          <ChevronRight size={15} />
        </button>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center mb-1.5">
        {daysOfWeek.map((d) => (
          <span key={`day-header-${d}`} className="text-[10px] font-bold text-zinc-500 uppercase">
            {d}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1">
        {daysArray.map((day, idx) => {
          if (day === null) {
            return <div key={`empty-${idx}`} />;
          }
          const isSelected = selectedDay === day;
          return (
            <button
              key={`day-btn-${day}`}
              type="button"
              onClick={() => onSelectDay(day)}
              className={cn(
                "h-8 text-xs font-semibold rounded-lg flex items-center justify-center transition-all",
                isSelected
                  ? "bg-emerald-500 text-black font-extrabold"
                  : "text-zinc-300 hover:bg-zinc-800 active:scale-90"
              )}
            >
              {day}
            </button>
          );
        })}
      </div>
    </div>
  );
}
