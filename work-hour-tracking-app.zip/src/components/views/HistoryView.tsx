"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { CalendarRange, Clock3, Trash2 } from "lucide-react";
import type { TimeEntry } from "@/lib/api";
import { MonthSwitcher, ViewHeader } from "@/components/ui";
import {
  TR_DAYS_S,
  TR_MONTHS_S,
  cn,
  entryMs,
  fmtClock,
  fmtDur,
  monthKey,
  monthLabel,
  pad,
  parseKey,
} from "@/lib/time";

interface Props {
  month: string;
  onMonth: (m: string) => void;
  entries: TimeEntry[] | null;
  nowMs: number;
  onDelete: (id: number) => void;
}

export default function HistoryView(p: Props) {
  const list = p.entries ?? [];
  const completed = list.filter((e) => e.type !== "work" || e.checkOut);
  const totalMs = completed.reduce((a, e) => a + entryMs(e), 0);
  const days = new Set(completed.map((e) => e.date)).size;
  const sorted = [...list].sort(
    (a, b) => b.id - a.id // Yeni eklenenler en üstte
  );

  return (
    <div>
      <ViewHeader
        kicker="Aylık Puantaj"
        title="Geçmiş"
        right={
          <MonthSwitcher
            month={p.month}
            onChange={p.onMonth}
            max={monthKey()}
          />
        }
      />

      {/* Özet Kartları */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Toplam Kayıt", value: String(list.length) },
          { label: "Çalışılan Gün", value: `${days} Gün` },
          { label: "Toplam Süre", value: fmtDur(totalMs) },
        ].map((s) => (
          <div key={s.label} className="bg-zinc-950 border border-zinc-900 rounded-2xl p-4 text-center">
            <div className="text-base font-extrabold text-zinc-100 tabular-nums">{s.value}</div>
            <div className="mt-1 text-[10px] font-bold uppercase tracking-wider text-zinc-500">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      {/* Kayıt Listesi */}
      {p.entries === null ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-16 animate-pulse rounded-2xl bg-zinc-900/50 border border-zinc-900"
            />
          ))}
        </div>
      ) : sorted.length === 0 ? (
        <div className="py-16 text-center">
          <span className="grid size-12 place-items-center rounded-2xl bg-zinc-900 text-zinc-600 mx-auto mb-4">
            <CalendarRange size={20} />
          </span>
          <p className="text-sm font-bold text-zinc-400">Bu Ayda Kayıt Yok</p>
          <p className="text-xs text-zinc-600 mt-1 max-w-[240px] mx-auto leading-relaxed">
            {monthLabel(p.month)} ayına ait çalışma veya izin kaydı eklenmemiş.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map((e) => (
            <Row key={e.id} e={e} nowMs={p.nowMs} onDelete={p.onDelete} />
          ))}
        </div>
      )}
    </div>
  );
}

function Row({
  e,
  nowMs,
  onDelete,
}: {
  e: TimeEntry;
  nowMs: number;
  onDelete: (id: number) => void;
}) {
  const [confirm, setConfirm] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  const d = parseKey(e.date);
  const open = !e.checkOut && e.type === "work";
  const ms = entryMs(e, nowMs);
  const isLeave = e.type === "paid_leave" || e.type === "unpaid_leave";

  const handleDelete = () => {
    if (confirm) {
      if (timer.current) clearTimeout(timer.current);
      onDelete(e.id);
    } else {
      setConfirm(true);
      timer.current = setTimeout(() => setConfirm(false), 2400);
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      className="bg-zinc-950 border border-zinc-900/70 hover:border-zinc-800 rounded-2xl p-4 flex items-center justify-between gap-4 transition-all"
    >
      {/* Gün / Ay Rozeti */}
      <div className="w-12 shrink-0 rounded-xl border border-zinc-900 bg-zinc-900/40 py-2 text-center">
        <div className="tabular-nums text-base font-extrabold text-zinc-100 leading-none">
          {pad(d.getDate())}
        </div>
        <div className="mt-1 text-[9px] font-bold uppercase tracking-wider text-zinc-500">
          {TR_MONTHS_S[d.getMonth()]}
        </div>
      </div>

      {/* Kayıt Detayı */}
      <div className="min-w-0 flex-1">
        <div className="text-sm font-bold text-zinc-100 flex items-center gap-2">
          {isLeave ? (
            <span className={cn(
              "text-xs px-2 py-0.5 rounded-md font-bold",
              e.type === "paid_leave" ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"
            )}>
              {e.type === "paid_leave" ? "Ücretli İzin" : "Ücretsiz İzin"}
            </span>
          ) : (
            <span className="tabular-nums">
              {fmtClock(e.checkIn, false)} <span className="text-zinc-600 font-normal">→</span>{" "}
              {e.checkOut ? fmtClock(e.checkOut, false) : <span className="text-emerald-400 font-bold">aktif</span>}
            </span>
          )}
          {e.isManual && !isLeave && (
            <span className="text-[10px] font-medium bg-zinc-900 text-zinc-500 px-1.5 py-0.5 rounded">
              Manuel
            </span>
          )}
        </div>
        
        <div className="mt-1 text-xs text-zinc-500 flex items-center gap-1.5 truncate">
          <span>{TR_DAYS_S[d.getDay()]}</span>
          {e.notes && (
            <>
              <span className="text-zinc-700">•</span>
              <span className="truncate italic text-zinc-400">{e.notes}</span>
            </>
          )}
        </div>
      </div>

      {/* Sağ Taraf: Süre & Silme Butonu */}
      <div className="flex items-center gap-3 shrink-0">
        <span
          className={cn(
            "tabular-nums text-xs font-bold px-2.5 py-1 rounded-full",
            e.type === "paid_leave" && "bg-emerald-500/10 text-emerald-400",
            e.type === "unpaid_leave" && "bg-amber-500/10 text-amber-400",
            open && "bg-emerald-500/10 text-emerald-400",
            !open && !isLeave && "bg-zinc-900 text-zinc-300",
          )}
        >
          {e.type === "unpaid_leave" ? "0sa" : fmtDur(ms)}
        </span>

        {!open && (
          <button
            aria-label={confirm ? "Silmeyi onayla" : "Kaydı sil"}
            onClick={handleDelete}
            className={cn(
              "grid size-8 place-items-center rounded-xl transition-all active:scale-90",
              confirm
                ? "bg-rose-500 text-white shadow-lg shadow-rose-500/20"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-500 hover:text-rose-400"
            )}
          >
            <Trash2 size={13} strokeWidth={2.4} />
          </button>
        )}
      </div>
    </motion.div>
  );
}
