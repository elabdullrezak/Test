import {
  CalendarDays,
  Sparkles,
  Timer,
  UserCheck,
  type LucideIcon,
} from "lucide-react";
import MesaiApp from "@/components/MesaiApp";

export default function Page() {
  return (
    <main className="relative min-h-[100dvh] w-full overflow-x-clip bg-zinc-950 text-white">
      {/* Premium minimal arka plan ışımaları */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden z-0">
        <div className="absolute left-[10%] top-[10%] h-[340px] w-[340px] rounded-full bg-emerald-500/[0.04] blur-[120px]" />
        <div className="absolute right-[10%] bottom-[10%] h-[340px] w-[340px] rounded-full bg-amber-500/[0.03] blur-[120px]" />
      </div>

      <div className="relative z-10 mx-auto flex min-h-[100dvh] w-full max-w-5xl items-center justify-center gap-12 lg:gap-20 p-4 sm:p-6 lg:p-8">
        {/* Sol Panel: Masaüstü Tanıtım (Büyük ekranlarda görünür) */}
        <aside className="hidden max-w-[360px] shrink-0 flex-col lg:flex">
          <span className="inline-flex w-fit items-center gap-1.5 rounded-full bg-zinc-900 border border-zinc-800 px-3.5 py-1.5 text-[10px] font-bold tracking-[0.18em] text-zinc-400">
            <Sparkles size={11} className="text-emerald-400" />
            PROFESYONEL PUANTAJ
          </span>
          
          <h1 className="mt-5 bg-gradient-to-br from-white via-zinc-200 to-zinc-600 bg-clip-text text-6xl font-black leading-none tracking-tight text-transparent">
            Mesai<span className="text-emerald-500">.</span>
          </h1>
          
          <p className="mt-4 text-[13.5px] leading-relaxed text-zinc-400">
            Tek dokunuşla canlı mesai başlatın, geçmişe yönelik çalışma saatlerinizi ekleyin veya izinli günlerinizi puantaja dahil edin.
          </p>

          <ul className="mt-8 space-y-4">
            {FEATURES.map((f) => (
              <li key={f.title} className="flex items-start gap-3.5">
                <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-zinc-900 border border-zinc-800/80 text-emerald-400">
                  <f.icon size={16} strokeWidth={2.2} />
                </span>
                <div>
                  <span className="block text-[13.5px] font-bold text-zinc-100">{f.title}</span>
                  <span className="mt-0.5 block text-xs leading-snug text-zinc-500">
                    {f.sub}
                  </span>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-10 border-t border-zinc-900 pt-6 text-[10px] font-bold tracking-widest text-zinc-600 uppercase">
            Çoklu Kullanıcı &amp; Güvenli PIN Koruması
          </div>
        </aside>

        {/* Sağ Panel: Esnek ve Modern Uygulama Bölümü */}
        <section className="relative w-full max-w-md h-[100dvh] sm:h-[780px] sm:rounded-3xl border border-transparent sm:border-zinc-900 bg-zinc-950/80 shadow-2xl backdrop-blur-2xl overflow-hidden flex flex-col">
          {/* iOS'a uygun temiz üst kulaklık alanı (yalnızca estetik için, kaba değil) */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 rounded-full bg-zinc-950 border border-zinc-900/60 z-30 pointer-events-none hidden sm:block" />
          
          <MesaiApp />
        </section>
      </div>
    </main>
  );
}

const FEATURES: { icon: LucideIcon; title: string; sub: string }[] = [
  {
    icon: Timer,
    title: "Canlı Giriş / Çıkış",
    sub: "Saniye saniye mesai takibi ve dinamik kronometre sayacı.",
  },
  {
    icon: CalendarDays,
    title: "Geçmiş Mesai &amp; İzin Kaydı",
    sub: "Eski günlere ait mesailer ile ücretli/ücretsiz izin günleri ekleme.",
  },
  {
    icon: UserCheck,
    title: "Çoklu Kişi ve PIN Şifresi",
    sub: "Her kullanıcıya ait özel profil, şifre ve ayrı saatlik ücret.",
  },
];
