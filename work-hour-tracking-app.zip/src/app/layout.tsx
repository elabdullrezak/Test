import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import type { ReactNode } from "react";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });

export const metadata: Metadata = {
  title: "Mesai — Vardiya Takip",
  description:
    "Giriş–çıkış kaydı, aylık puantaj ve saatlik ücrete göre ay sonu kazanç hesabı.",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Mesai",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#050507",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="tr" className={inter.variable}>
      <body className="bg-ios-bg font-sans text-white antialiased">
        {children}
      </body>
    </html>
  );
}
