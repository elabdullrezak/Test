import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const dynamic = "force-dynamic";

/** POST /api/auth/login → PIN doğrulaması yapar */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      userId?: number;
      pin?: string;
    };

    const userId = Number(body.userId);
    const pin = typeof body.pin === "string" ? body.pin.trim() : "";

    if (!userId || !pin) {
      return NextResponse.json(
        { error: "Kullanıcı ID ve PIN gereklidir" },
        { status: 400 },
      );
    }

    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    if (!user) {
      return NextResponse.json({ error: "Profil bulunamadı" }, { status: 404 });
    }

    if (user.pin !== pin) {
      return NextResponse.json({ error: "Hatalı şifre/PIN girdiniz" }, { status: 401 });
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name, // Login olunca full ismini dönüyoruz ki kendisi görebilsin
        hourlyRate: user.hourlyRate,
        maskName: user.maskName,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Giriş işlemi başarısız" }, { status: 500 });
  }
}
