import { NextRequest, NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { maskSurname } from "@/lib/time";

export const dynamic = "force-dynamic";

/** GET /api/auth/users → Kayıtlı tüm kullanıcıları döndürür (Gerektiğinde soyadı maskelenmiş olarak) */
export async function GET() {
  try {
    const list = await db
      .select({
        id: users.id,
        name: users.name,
        hourlyRate: users.hourlyRate,
        maskName: users.maskName,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(asc(users.name));

    // maskName aktif olan kullanıcıların adlarını liste için maskele
    const processedList = list.map((u) => ({
      id: u.id,
      name: u.maskName ? maskSurname(u.name) : u.name,
      hourlyRate: u.hourlyRate,
      maskName: u.maskName,
    }));

    return NextResponse.json({ users: processedList });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Kullanıcılar yüklenemedi" }, { status: 500 });
  }
}

/** POST /api/auth/users → Yeni profil oluşturur */
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as {
      name?: string;
      pin?: string;
      hourlyRate?: number;
      maskName?: boolean;
    };

    const name = typeof body.name === "string" ? body.name.trim() : "";
    const pin = typeof body.pin === "string" ? body.pin.trim() : "";
    const hourlyRate = Number(body.hourlyRate) || 250;
    const maskName = !!body.maskName;

    if (!name || name.length < 2) {
      return NextResponse.json(
        { error: "İsim en az 2 karakter olmalıdır" },
        { status: 400 },
      );
    }

    if (!/^\d{4}$/.test(pin)) {
      return NextResponse.json(
        { error: "Şifre/PIN tam olarak 4 haneli sayı olmalıdır" },
        { status: 400 },
      );
    }

    if (hourlyRate <= 0 || hourlyRate > 1_000_000) {
      return NextResponse.json(
        { error: "Geçerli bir saatlik ücret girin" },
        { status: 400 },
      );
    }

    // İsmin benzersiz olmasını kontrol edelim
    const existing = await db.select().from(users).where(eq(users.name, name)).limit(1);
    if (existing.length > 0) {
      return NextResponse.json(
        { error: "Bu isimde başka bir profil zaten var" },
        { status: 409 },
      );
    }

    const [newUser] = await db
      .insert(users)
      .values({
        name,
        pin,
        hourlyRate,
        maskName,
      })
      .returning({
        id: users.id,
        name: users.name,
        hourlyRate: users.hourlyRate,
        maskName: users.maskName,
      });

    return NextResponse.json({ user: newUser }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Profil oluşturulamadı" }, { status: 500 });
  }
}
