import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const dynamic = "force-dynamic";

/** PUT /api/auth/profile → Oturum açmış kullanıcının kendi profil bilgilerini günceller */
export async function PUT(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const body = (await req.json().catch(() => ({}))) as {
      name?: string;
      pin?: string;
      hourlyRate?: number;
      maskName?: boolean;
    };

    // Güncellenecek alanları hazırla
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const pin = typeof body.pin === "string" ? body.pin.trim() : "";
    const hourlyRate = Number(body.hourlyRate);
    const maskName = body.maskName !== undefined ? !!body.maskName : undefined;

    const updateData: Record<string, any> = {};

    if (name) {
      if (name.length < 2) {
        return NextResponse.json({ error: "İsim en az 2 karakter olmalıdır" }, { status: 400 });
      }
      updateData.name = name;
    }

    if (pin) {
      if (!/^\d{4}$/.test(pin)) {
        return NextResponse.json({ error: "PIN şifresi tam 4 haneli sayı olmalıdır" }, { status: 400 });
      }
      updateData.pin = pin;
    }

    if (body.hourlyRate !== undefined) {
      if (!Number.isFinite(hourlyRate) || hourlyRate <= 0 || hourlyRate > 1_000_000) {
        return NextResponse.json({ error: "Geçerli bir saatlik ücret girin" }, { status: 400 });
      }
      updateData.hourlyRate = hourlyRate;
    }

    if (maskName !== undefined) {
      updateData.maskName = maskName;
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ error: "Güncellenecek veri gönderilmedi" }, { status: 400 });
    }

    const [updatedUser] = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, userId))
      .returning({
        id: users.id,
        name: users.name,
        hourlyRate: users.hourlyRate,
        maskName: users.maskName,
      });

    return NextResponse.json({ user: updatedUser });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Profil güncellenemedi" }, { status: 500 });
  }
}

/** DELETE /api/auth/profile → Oturum açmış kullanıcının kendi profilini ve tüm mesailerini siler */
export async function DELETE(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    // users tablosundan silindiğinde onDelete: cascade ile bağlı tüm time_entries otomatik silinir.
    await db.delete(users).where(eq(users.id, userId));

    return NextResponse.json({ success: true, message: "Profil ve bağlı tüm kayıtlar kalıcı olarak silindi" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Profil silinemedi" }, { status: 500 });
  }
}
