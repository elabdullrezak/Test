import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export const dynamic = "force-dynamic";

/** GET /api/settings → Kullanıcının saatlik ücretini döner */
export async function GET(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
    if (!user) {
      return NextResponse.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });
    }

    return NextResponse.json({ hourlyRate: user.hourlyRate });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Ayarlar yüklenemedi" }, { status: 500 });
  }
}

/** PUT /api/settings → Kullanıcının saatlik ücretini günceller */
export async function PUT(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const body = (await req.json().catch(() => ({}))) as { hourlyRate?: unknown };
    const rate = Number(body.hourlyRate);

    if (!Number.isFinite(rate) || rate < 0 || rate > 1_000_000) {
      return NextResponse.json(
        { error: "Geçerli bir saatlik ücret girin" },
        { status: 400 },
      );
    }

    await db.update(users).set({ hourlyRate: rate }).where(eq(users.id, userId));

    return NextResponse.json({ hourlyRate: rate });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Saatlik ücret güncellenemedi" }, { status: 500 });
  }
}
