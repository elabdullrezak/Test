import { NextRequest, NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { timeEntries } from "@/db/schema";

export const dynamic = "force-dynamic";

/** DELETE /api/entries/:id → Kaydı siler */
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const { id } = await params;
    const num = Number(id);
    if (!Number.isInteger(num) || num <= 0) {
      return NextResponse.json({ error: "Geçersiz kayıt" }, { status: 400 });
    }

    // Kullanıcıya ait olduğundan emin olalım
    const deleted = await db
      .delete(timeEntries)
      .where(and(eq(timeEntries.id, num), eq(timeEntries.userId, userId)))
      .returning();

    if (deleted.length === 0) {
      return NextResponse.json({ error: "Kayıt bulunamadı veya yetkiniz yok" }, { status: 404 });
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Kayıt silinemedi" }, { status: 500 });
  }
}
