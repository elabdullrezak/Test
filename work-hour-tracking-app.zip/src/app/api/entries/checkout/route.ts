import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { timeEntries } from "@/db/schema";

export const dynamic = "force-dynamic";

/** POST /api/entries/checkout → En son açık mesaiyi kapatır (ÇIKIŞ) */
export async function POST(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const [open] = await db
      .select()
      .from(timeEntries)
      .where(and(eq(timeEntries.userId, userId), isNull(timeEntries.checkOut)))
      .orderBy(desc(timeEntries.checkIn))
      .limit(1);

    if (!open) {
      return NextResponse.json(
        { error: "Açık bir mesai kaydı bulunamadı" },
        { status: 404 },
      );
    }

    const [entry] = await db
      .update(timeEntries)
      .set({ checkOut: new Date() })
      .where(eq(timeEntries.id, open.id))
      .returning();

    return NextResponse.json({ entry });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Çıkış işlemi kaydedilemedi" }, { status: 500 });
  }
}
