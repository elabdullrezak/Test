import { NextRequest, NextResponse } from "next/server";
import { and, asc, gte, isNull, lt, eq } from "drizzle-orm";
import { db } from "@/db";
import { timeEntries } from "@/db/schema";

export const dynamic = "force-dynamic";

/** 
 * GET /api/entries?month=YYYY-MM
 * x-user-id başlığındaki kullanıcının o aya ait tüm kayıtlarını döner.
 */
export async function GET(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const month = req.nextUrl.searchParams.get("month");
    if (!month || !/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
      return NextResponse.json(
        { error: "Geçerli bir ay gerekli (YYYY-MM)" },
        { status: 400 },
      );
    }

    const [y, m] = month.split("-").map(Number);
    const start = `${month}-01`;
    const next =
      m === 12
        ? `${y + 1}-01-01`
        : `${y}-${String(m + 1).padStart(2, "0")}-01`;

    const rows = await db
      .select()
      .from(timeEntries)
      .where(
        and(
          eq(timeEntries.userId, userId),
          gte(timeEntries.date, start),
          lt(timeEntries.date, next)
        )
      )
      .orderBy(asc(timeEntries.date), asc(timeEntries.checkIn));

    return NextResponse.json({ entries: rows });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Kayıtlar listelenemedi" }, { status: 500 });
  }
}

/** 
 * POST /api/entries
 * Yeni giriş / izin günü / manuel geçmiş mesai ekleme
 */
export async function POST(req: NextRequest) {
  try {
    const userId = Number(req.headers.get("x-user-id"));
    if (!userId) {
      return NextResponse.json({ error: "Oturum açmanız gerekmektedir" }, { status: 401 });
    }

    const body = (await req.json().catch(() => ({}))) as {
      date?: string;
      type?: "work" | "paid_leave" | "unpaid_leave";
      isManual?: boolean;
      checkInTime?: string; // HH:MM past entry için
      checkOutTime?: string; // HH:MM past entry için
      manualHours?: number; // alternatif olarak direkt saat
      notes?: string;
    };

    const date = body.date || "";
    if (!/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(date)) {
      return NextResponse.json({ error: "Geçersiz veya eksik tarih (YYYY-MM-DD)" }, { status: 400 });
    }

    const type = body.type || "work";
    const notes = body.notes ? body.notes.trim() : null;

    // 1. İzinli Gün Ekleme (Ücretli veya Ücretsiz İzin)
    if (type === "paid_leave" || type === "unpaid_leave") {
      // O gün için başka kayıt var mı kontrolü
      const dayEntries = await db
        .select()
        .from(timeEntries)
        .where(and(eq(timeEntries.userId, userId), eq(timeEntries.date, date)));
      
      if (dayEntries.length > 0) {
        return NextResponse.json(
          { error: "Bu tarihte zaten kayıtlı mesai veya izin mevcut" },
          { status: 409 },
        );
      }

      // Ücretli izin varsayılan olarak günlük 8 saat olarak işlenir
      const hours = type === "paid_leave" ? (body.manualHours || 8) : 0;

      const [entry] = await db
        .insert(timeEntries)
        .values({
          userId,
          date,
          type,
          isManual: true,
          manualHours: hours,
          notes: notes || (type === "paid_leave" ? "Ücretli İzin" : "Ücretsiz İzin"),
        })
        .returning();

      return NextResponse.json({ entry }, { status: 201 });
    }

    // 2. Geçmişe Yönelik Manuel Mesai Ekleme (isManual = true)
    if (body.isManual) {
      const checkInStr = body.checkInTime || ""; // HH:MM
      const checkOutStr = body.checkOutTime || ""; // HH:MM

      if (!/^\d{2}:\d{2}$/.test(checkInStr) || !/^\d{2}:\d{2}$/.test(checkOutStr)) {
        return NextResponse.json({ error: "Giriş ve çıkış saatleri gereklidir (SS:DD)" }, { status: 400 });
      }

      const checkIn = new Date(`${date}T${checkInStr}:00`);
      let checkOut = new Date(`${date}T${checkOutStr}:00`);

      // Eğer çıkış saati girişten önceyse (gece vardiyası), ertesi güne taşıyabiliriz.
      // Ama sade ve güvenli tutmak için aynı günde olmasını şart koşalım.
      if (checkOut.getTime() <= checkIn.getTime()) {
        return NextResponse.json({ error: "Çıkış saati, giriş saatinden sonra olmalıdır" }, { status: 400 });
      }

      // Saat farkını hesapla
      const diffMs = checkOut.getTime() - checkIn.getTime();
      const hours = diffMs / 3_600_000;

      const [entry] = await db
        .insert(timeEntries)
        .values({
          userId,
          date,
          type: "work",
          isManual: true,
          checkIn,
          checkOut,
          manualHours: Math.round(hours * 100) / 100,
          notes: notes || "Geçmiş Mesai",
        })
        .returning();

      return NextResponse.json({ entry }, { status: 201 });
    }

    // 3. Normal Giriş Yapma (Canlı Kronometre)
    // O gün için halihazırda bir izin kaydı (ücretli/ücretsiz) olup olmadığını kontrol et
    const existingLeave = await db
      .select()
      .from(timeEntries)
      .where(and(
        eq(timeEntries.userId, userId),
        eq(timeEntries.date, date),
        and(eq(timeEntries.type, "paid_leave"), eq(timeEntries.type, "unpaid_leave")) // paid veya unpaid
      ))
      .limit(1);

    // Drizzle syntax düzeltme: type in paid_leave, unpaid_leave
    const todayLeaves = await db
      .select()
      .from(timeEntries)
      .where(and(
        eq(timeEntries.userId, userId),
        eq(timeEntries.date, date)
      ));
    
    const hasLeaveToday = todayLeaves.some(e => e.type === "paid_leave" || e.type === "unpaid_leave");
    if (hasLeaveToday) {
      return NextResponse.json(
        { error: "Bugün izinli olarak kayıtlısınız, yeni mesai başlatamazsınız." },
        { status: 409 }
      );
    }

    // Açık aktif bir mesai olup olmadığını kontrol et
    const open = await db
      .select()
      .from(timeEntries)
      .where(and(eq(timeEntries.userId, userId), isNull(timeEntries.checkOut)))
      .limit(1);

    if (open.length > 0) {
      return NextResponse.json(
        { error: "Zaten açık bir mesainiz var. Önce çıkış yapmalısınız." },
        { status: 409 },
      );
    }

    const [entry] = await db
      .insert(timeEntries)
      .values({
        userId,
        date,
        type: "work",
        checkIn: new Date(),
        isManual: false,
      })
      .returning();

    return NextResponse.json({ entry }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Kayıt eklenemedi" }, { status: 500 });
  }
}
