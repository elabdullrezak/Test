/** API istemcisi + paylaşılan tipler */

export interface UserProfile {
  id: number;
  name: string;
  hourlyRate: number;
  maskName: boolean;
}

export interface TimeEntry {
  id: number;
  userId: number;
  date: string; // YYYY-MM-DD
  type: string; // 'work' | 'paid_leave' | 'unpaid_leave'
  checkIn: string | null; // ISO
  checkOut: string | null; // ISO | null
  isManual: boolean;
  manualHours: number | null;
  notes: string | null;
}

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

// LocalStorage'dan aktif kullanıcı ID'sini getirir
export function getActiveUserId(): string {
  if (typeof window !== "undefined") {
    return localStorage.getItem("active_user_id") || "";
  }
  return "";
}

async function req<T>(input: string, init?: RequestInit): Promise<T> {
  const headers = new Headers(init?.headers ?? {});
  headers.set("Content-Type", "application/json");
  
  const userId = getActiveUserId();
  if (userId) {
    headers.set("x-user-id", userId);
  }

  const res = await fetch(input, {
    ...init,
    headers,
    cache: "no-store",
  });
  
  if (!res.ok) {
    let msg = "Bir şeyler ters gitti";
    try {
      const data = (await res.json()) as { error?: string };
      if (data.error) msg = data.error;
    } catch {
      /* yoksay */
    }
    throw new ApiError(msg, res.status);
  }
  return (await res.json()) as T;
}

export const api = {
  // Auth Uçları
  listUsers: () =>
    req<{ users: UserProfile[] }>("/api/auth/users"),
  createUser: (name: string, pin: string, hourlyRate: number, maskName = false) =>
    req<{ user: UserProfile }>("/api/auth/users", {
      method: "POST",
      body: JSON.stringify({ name, pin, hourlyRate, maskName }),
    }),
  login: (userId: number, pin: string) =>
    req<{ success: boolean; user: UserProfile }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ userId, pin }),
    }),

  // Kendi Profilini Yönetme (Yeni)
  updateProfile: (data: { name?: string; pin?: string; hourlyRate?: number; maskName?: boolean }) =>
    req<{ user: UserProfile }>("/api/auth/profile", {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  deleteProfile: () =>
    req<{ success: boolean; message: string }>("/api/auth/profile", {
      method: "DELETE",
    }),

  // Kayıt Uçları
  listEntries: (month: string) =>
    req<{ entries: TimeEntry[] }>(`/api/entries?month=${month}`),
  
  checkIn: (date: string) =>
    req<{ entry: TimeEntry }>("/api/entries", {
      method: "POST",
      body: JSON.stringify({ date }),
    }),

  addPastEntry: (data: {
    date: string;
    checkInTime: string;
    checkOutTime: string;
    notes?: string;
  }) =>
    req<{ entry: TimeEntry }>("/api/entries", {
      method: "POST",
      body: JSON.stringify({
        ...data,
        type: "work",
        isManual: true,
      }),
    }),

  addLeaveEntry: (data: {
    date: string;
    type: "paid_leave" | "unpaid_leave";
    manualHours?: number;
    notes?: string;
  }) =>
    req<{ entry: TimeEntry }>("/api/entries", {
      method: "POST",
      body: JSON.stringify({
        ...data,
        isManual: true,
      }),
    }),

  checkOut: () =>
    req<{ entry: TimeEntry }>("/api/entries/checkout", { method: "POST" }),
  
  removeEntry: (id: number) =>
    req<{ ok: true }>(`/api/entries/${id}`, { method: "DELETE" }),
  
  getRate: () => req<{ hourlyRate: number }>("/api/settings"),
  
  saveRate: (hourlyRate: number) =>
    req<{ hourlyRate: number }>("/api/settings", {
      method: "PUT",
      body: JSON.stringify({ hourlyRate }),
    }),
};
