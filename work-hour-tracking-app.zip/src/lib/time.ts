/* Tarih & süre yardımcıları — Türkçe */

export const pad = (n: number) => String(n).padStart(2, "0");

/** Yerel gün anahtarı: YYYY-MM-DD */
export function dateKey(d: Date = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Yerel ay anahtarı: YYYY-MM */
export function monthKey(d: Date = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
}

export function shiftMonth(key: string, delta: number) {
  const [y, m] = key.split("-").map(Number);
  return monthKey(new Date(y, m - 1 + delta, 1));
}

export const TR_MONTHS = [
  "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran",
  "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık",
];
export const TR_MONTHS_S = [
  "Oca", "Şub", "Mar", "Nis", "May", "Haz",
  "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara",
];
export const TR_DAYS = [
  "Pazar", "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi",
];
export const TR_DAYS_S = ["Paz", "Pzt", "Sal", "Çar", "Per", "Cum", "Cmt"];

/** "YYYY-MM" | "YYYY-MM-DD" → yerel Date */
export function parseKey(key: string) {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function monthLabel(key: string) {
  const d = parseKey(key.length === 7 ? `${key}-01` : key);
  return `${TR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** Saat:dakika:saniye — 09:02:14 */
export function fmtClock(input: Date | string | null | undefined, withSeconds = true) {
  if (!input) return "—";
  const d = typeof input === "string" ? new Date(input) : input;
  const hm = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  return withSeconds ? `${hm}:${pad(d.getSeconds())}` : hm;
}

export function durParts(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  return {
    h: Math.floor(s / 3600),
    m: Math.floor((s % 3600) / 60),
    s: s % 60,
    hours: s / 3600,
  };
}

/** 8sa 12dk / 45dk 30sn gibi kompakt süre */
export function fmtDur(ms: number, withSeconds = false) {
  const { h, m, s } = durParts(ms);
  if (h > 0) return withSeconds ? `${h}sa ${m}dk ${s}sn` : `${h}sa ${m}dk`;
  if (m > 0) return withSeconds ? `${m}dk ${s}sn` : `${m}dk`;
  return `${s}sn`;
}

/** Canlı kronometre için HH:MM:SS */
export function fmtHMS(ms: number) {
  const { h, m, s } = durParts(ms);
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

const moneyFmt0 = new Intl.NumberFormat("tr-TR", {
  style: "currency",
  currency: "TRY",
  maximumFractionDigits: 0,
});
const moneyFmt2 = new Intl.NumberFormat("tr-TR", {
  style: "currency",
  currency: "TRY",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
export function fmtMoney(n: number) {
  return Number.isInteger(Math.round(n * 100) / 100)
    ? moneyFmt0.format(n)
    : moneyFmt2.format(n);
}

const numFmt = new Intl.NumberFormat("tr-TR", { maximumFractionDigits: 2 });
export const fmtNum = (n: number) => numFmt.format(n);

/** 
 * Bir kaydın süresi (çıkış yoksa şimdiye kadar) — ms
 * İzin günüyse ve `manualHours` varsa onu milisaniyeye çevirir.
 */
export function entryMs(
  e: { 
    checkIn: string | null; 
    checkOut: string | null; 
    type?: string; 
    manualHours?: number | null 
  },
  nowMs: number = Date.now(),
) {
  // İzin durumları
  if (e.type === "paid_leave") {
    return (e.manualHours || 8) * 3600000;
  }
  if (e.type === "unpaid_leave") {
    return 0;
  }
  if (e.manualHours && !e.checkIn) {
    return e.manualHours * 3600000;
  }
  if (!e.checkIn) return 0;
  const a = new Date(e.checkIn).getTime();
  const b = e.checkOut ? new Date(e.checkOut).getTime() : nowMs;
  return Math.max(0, b - a);
}

export function greeting(d: Date = new Date()) {
  const h = d.getHours();
  if (h >= 5 && h < 11) return "Günaydın";
  if (h >= 11 && h < 18) return "İyi günler";
  if (h >= 18 && h < 23) return "İyi akşamlar";
  return "İyi geceler";
}

/** 
 * İsim ve soyismin sadece baş harfini gösterecek şekilde maskeler.
 * Örn: "Ahmet Yılmaz" -> "Ahmet Y."
 * Örn: "Mehmet Ali Demirci" -> "Mehmet Ali D."
 */
export function maskSurname(fullName: string): string {
  const parts = fullName.trim().split(/\s+/);
  if (parts.length <= 1) return fullName;
  
  const surname = parts[parts.length - 1];
  const firstLetter = surname.charAt(0).toUpperCase();
  const firstNames = parts.slice(0, parts.length - 1).join(" ");
  
  return `${firstNames} ${firstLetter}.`;
}

export const cn = (...c: (string | false | null | undefined)[]) =>
  c.filter(Boolean).join(" ");
